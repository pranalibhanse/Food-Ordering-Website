<div id="search-lightbox-wrap" class="tf_hide tf_w tf_scrollbar">
	<div class="search-lightbox">
		<div id="searchform-wrap">
			<?php get_search_form(); ?>
		</div>
		<!-- /searchform wrap -->
		<div class="search-results-wrap tf_rel"></div>
	</div>
	<i id="close-search-box" class="tf_close"></i>
</div>
<!-- /search-lightbox -->
